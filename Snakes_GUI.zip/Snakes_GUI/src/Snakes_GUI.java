
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author kaioc
 */
public class Snakes_GUI extends javax.swing.JFrame {
    private static String[] snake = new String [4];
    private static String[] ranking = new String [4];
    private static String[] assistanceTime = new String [4];
    
    public Snakes_GUI() {
        initComponents();
         populatesSnakeInfo();
    }
     private void populatesSnakeInfo() {
         try {
             BufferedReader  br = null;
             String strCurrentLine;
             br = new BufferedReader(new FileReader("snakes.txt"));
             int x = 0;
             while((strCurrentLine = br.readLine()) != null) {
                 snake[x] = (strCurrentLine);
                 this.cmb_Snake_Types.addItem(snake[x]);
                 
                 strCurrentLine = br.readLine();
                 ranking[x] = (strCurrentLine);
                 
                 strCurrentLine = br.readLine();
                 assistanceTime[x] = (strCurrentLine);
                 
                 x += 1;
             }
         }
         catch(Exception ex) {
            JOptionPane.showMessageDialog(this, "Error" + ex.toString());
          }
     }
     
     private void displaySnakeInfo() {
         DefaultListModel dlm = new DefaultListModel();
         int snakeSelected = this.cmb_Snake_Types.getSelectedIndex();
         
         dlm.addElement(snake[snakeSelected]);
         dlm.addElement(ranking[snakeSelected]);
         dlm.addElement(assistanceTime[snakeSelected]);
         this.ltb_Snake_Details.setModel(dlm);
     }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        cmb_Snake_Types = new javax.swing.JComboBox<>();
        lbl_Select_Snake = new javax.swing.JLabel();
        btn_Process = new javax.swing.JButton();
        btn_Clear = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        ltb_Snake_Details = new javax.swing.JList<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Snake Info");

        cmb_Snake_Types.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N

        lbl_Select_Snake.setText("Select snake:");

        btn_Process.setText("Process");
        btn_Process.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_ProcessActionPerformed(evt);
            }
        });

        btn_Clear.setText("Clear");
        btn_Clear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_ClearActionPerformed(evt);
            }
        });

        jScrollPane1.setViewportView(ltb_Snake_Details);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(52, 52, 52)
                .addComponent(btn_Process)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btn_Clear)
                        .addGap(68, 68, 68))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(64, 64, 64)
                        .addComponent(lbl_Select_Snake, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(cmb_Snake_Types, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(layout.createSequentialGroup()
                .addGap(61, 61, 61)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 473, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 95, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cmb_Snake_Types, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_Select_Snake))
                .addGap(44, 44, 44)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_Process)
                    .addComponent(btn_Clear))
                .addGap(26, 26, 26)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(30, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_ProcessActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_ProcessActionPerformed
        displaySnakeInfo();

    }//GEN-LAST:event_btn_ProcessActionPerformed

    private void btn_ClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_ClearActionPerformed
        
    }//GEN-LAST:event_btn_ClearActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Snakes_GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Snakes_GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Snakes_GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Snakes_GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Snakes_GUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_Clear;
    private javax.swing.JButton btn_Process;
    private javax.swing.JComboBox<String> cmb_Snake_Types;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lbl_Select_Snake;
    private javax.swing.JList<String> ltb_Snake_Details;
    // End of variables declaration//GEN-END:variables
}
